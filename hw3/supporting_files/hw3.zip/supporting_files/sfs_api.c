
#include "sfs_api.h"
#include "bitmap.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fuse.h>
#include <strings.h>
#include "disk_emu.h"
#define LASTNAME_FIRSTNAME_DISK "sfs_disk.disk"

// Values used in program
#define NUM_BLOCKS 1024  //maximum number of data blocks on the disk.
#define BLOCK_SIZE 1024
#define NEW_SFS_NAME "newSFS"
#define SFS_SIZE 1024
#define INODE_TABLE_LEN 100 // ask TA?
#define MAGIC 32134 // ask TA?
#define ROOT_DIR_INODE 1
#define SUPER_BLOCK_ADDR 0
#define SUPER_BLOCK_N_BLOCKS 1
#define MODE 777
#define FD_MAX_OPEN 100 //ask TA
#define FILE_ENTRY_MAX 99
#define FILE_ENTRY_TABLE_BLOCKS 3
#define FREE_BIT_MAP_ADDR 105

#define BITMAP_ROW_SIZE (NUM_BLOCKS/8) // this essentially mimcs the number of rows we have in the bitmap. we will have 128 rows. 

/* macros */
#define FREE_BIT(_data, _which_bit) \
    _data = _data | (1 << _which_bit)

#define USE_BIT(_data, _which_bit) \
    _data = _data & ~(1 << _which_bit)

// indirect ptr
typedef struct ind_p{
	int moreAddr[256];
} IndirPtr;


//Inode Table
inode_t iNodeTable[INODE_TABLE_LEN];
// File descriptor Table
file_descriptor fileDescriptorTable[FD_MAX_OPEN];
// File Entry table
directory_entry fileEntryTable[FILE_ENTRY_MAX];
// Variables to keep track of the current files
int numOfFiles;
int currFileNum;
void* blockBuffer;

// Given the inode index write that inode to disk
int inode_to_disk(int index){
	//printf("INODE TO INDEX %d\n", index);
	blockBuffer = (void*) malloc(BLOCK_SIZE);
	memset(blockBuffer, 0, BLOCK_SIZE);
	memcpy(blockBuffer, &iNodeTable[index], sizeof(inode_t));
	//fwrite(blockBuffer, BLOCK_SIZE, 1, stdout);
	if(write_blocks(index + SUPER_BLOCK_N_BLOCKS, 1, blockBuffer) == -1){
		//printf("iNode #%d not flushed.\n", index);
		free(blockBuffer);
		return -1;
	}
	free(blockBuffer);
	return 1;	
}

// Given directory entry to Disk
int file_entry_to_disk(){	
	blockBuffer = (void*) malloc(BLOCK_SIZE * FILE_ENTRY_TABLE_BLOCKS);
	memset(blockBuffer, 0, BLOCK_SIZE * FILE_ENTRY_TABLE_BLOCKS);
	memcpy(blockBuffer, fileEntryTable, sizeof(directory_entry) * FILE_ENTRY_MAX);
	if(write_blocks(INODE_TABLE_LEN + SUPER_BLOCK_N_BLOCKS ,FILE_ENTRY_TABLE_BLOCKS ,blockBuffer)== -1){
		free(blockBuffer);
		return -1;																				
	}
	free(blockBuffer);
	return 1;
}

// Store bitmap to disk
int bitmap_to_disk(){	
	blockBuffer = (void*) malloc(BLOCK_SIZE);
	memset(blockBuffer, 0, BLOCK_SIZE);
	memcpy(blockBuffer, free_bit_map, sizeof(uint8_t) * SIZE);
	if(write_blocks(FREE_BIT_MAP_ADDR ,1 ,blockBuffer)== -1){
		free(blockBuffer);
		return -1;																				
	}
	free(blockBuffer);
	return 1;
}
// Validate File Name 
int validate_name(const char * fileName){
	if (strlen(fileName) > 20){
        return 0;
    }
    char* ext = strchr(fileName, '.');
    if(strlen(ext) > 4){
        return 0;
    }
   	return 1;
}


// Check if file open
int is_file_open(int fileID){
	if(fileID < 0 || fileID >= FD_MAX_OPEN){		
		//printf("is_file_open: Wrong ID\n");
		return -1;
	}

	return fileDescriptorTable[fileID].inodeIndex;
}

void sfs_create() {
	// Initialize disk (API call)
	init_fresh_disk(NEW_SFS_NAME, BLOCK_SIZE, SFS_SIZE);

	// Store superblock in buffer
	superblock_t superBlock = {MAGIC, BLOCK_SIZE, SFS_SIZE, INODE_TABLE_LEN, ROOT_DIR_INODE};
	void* superBlockBuffer = (void*) malloc(BLOCK_SIZE); //ask TA
	memset(superBlockBuffer, 0, BLOCK_SIZE);
	memcpy(superBlockBuffer, &superBlock, sizeof(superblock_t));

	// Write to disk 
	if(write_blocks(SUPER_BLOCK_ADDR, SUPER_BLOCK_N_BLOCKS, superBlockBuffer) == -1){
		printf("ERROR : super block not writtne to memory \n");
	}
	// Free super block buffer
	free(superBlockBuffer);

	// init and write Inode for root directory
	inode_t root_inode = {MODE, 0, 0, 0, 1, {101, 102, 103, -1, -1, -1, -1, -1, -1, -1, -1, -1 }, -1};
	iNodeTable[0] = root_inode;
	inode_to_disk(0);
	printf("initialized the root inode\n");

	// init and write other inode to disk
	for (int i = 1 ; i <= INODE_TABLE_LEN; i++){ 
		inode_t inode = (inode_t){777, 0, i, 0, -1, {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1} , -1};
		iNodeTable[i] = inode;
		if(inode_to_disk(i)== -1){
			 return -1;
		}
	}

	// Initialize File descriptor table
	for(int i = 0; i < FD_MAX_OPEN; i++){
		fileDescriptorTable[i] = (file_descriptor){-1, NULL, -1};
	}

	// Initialize File Entry table
	for(int i = 0; i < FILE_ENTRY_MAX; i++){
		fileEntryTable[i].num= -1;
	}
	
	// File table written to disk
	file_entry_to_disk();

	// Write Bit Map to disk
	for (int i = 0; i < NUM_BLOCKS; i++){
		if (i <= SUPER_BLOCK_N_BLOCKS + INODE_TABLE_LEN + FILE_ENTRY_TABLE_BLOCKS){
			force_set_index(i);
		}else{
			rm_index(i);
		}
	}
	bitmap_to_disk();
	void* BlockBuffer = (void*) malloc(BITMAP_ROW_SIZE);
	memset(BlockBuffer, 0, BITMAP_ROW_SIZE);
	memcpy(BlockBuffer, free_bit_map, sizeof(uint8_t)); //ask TA
	write_blocks(FREE_BIT_MAP_ADDR, 1, BlockBuffer);
	force_set_index(FREE_BIT_MAP_ADDR);
	bitmap_to_disk();
	free(BlockBuffer);

	// Init the file tracker pointers
	numOfFiles = 0;
	currFileNum= 0;
}


/*
	Formats the virtual disk implemented by the disk em-
	ulator and creates an instance of the simple file system
	on top of it. The mksfs() has a fresh flag to signal that
	the file system should be created from scratch. If flag
	is false, the file system is opened from the disk (i.e.,
	we assume that a valid file system is already there in
	the file system). The support for persistence is impor-
	tant so you can reuse existing data or create a new file
	system.
*/
void mksfs(int fresh) {
	if (fresh){
		// Create a new clean sfs
		sfs_create();
	}
	else{
		// init buffer for super block
		superblock_t superBlock;
		blockBuffer = (void*) malloc(BLOCK_SIZE); //ask TA
		memset(blockBuffer, 0, BLOCK_SIZE);

		// get super block data from disk
		read_blocks(0, 1, blockBuffer);
		memcpy(&superBlock, blockBuffer, sizeof(superblock_t));

		// init disk (API CALL)
		init_disk(NEW_SFS_NAME, superBlock.block_size, superBlock.fs_size);

		// Get data for root directory
		memset(blockBuffer,0, BLOCK_SIZE);
		// Initialize i node table,
		int i;
		for (i = 0 ; i < INODE_TABLE_LEN ; i++){			 
			memset(blockBuffer, 0, BLOCK_SIZE);
			read_blocks(i + 1, 1,blockBuffer);				
			memcpy(&iNodeTable[i], blockBuffer, sizeof(inode_t));
			//printf("mksfs: inode.data_ptrs[0] : %d\n", iNodeTable[i].data_ptrs[0]);
		}
		//free(blockBuffer);
		// Init freebit mapping
		memset(blockBuffer, 0, BLOCK_SIZE);
		read_blocks(FREE_BIT_MAP_ADDR, 1,blockBuffer);				
		memcpy(free_bit_map, blockBuffer, sizeof(uint8_t) * SIZE);
		free(blockBuffer);

		void * blockBuffer1 = (void*) malloc(BLOCK_SIZE*3);
		memset(blockBuffer1, 0, BLOCK_SIZE*3);
		read_blocks(101,3, blockBuffer1);
		memcpy(fileEntryTable, blockBuffer1, sizeof(directory_entry) * 100);
		
		// Initialize File descriptor table
		for(int i = 0; i < FD_MAX_OPEN; i++){
			fileDescriptorTable[i] = (file_descriptor){-1, NULL, -1};
		}

		// init file tracking variables
		numOfFiles = 0;
		currFileNum = 0;
		for(int i = 0; i < FILE_ENTRY_MAX; i++){
			if (fileEntryTable[i].num !=1){
				numOfFiles++;
			}
		}
		free(blockBuffer);
	} 
	
}

void print_inodes(){
			for(int i =0 ; i < 5; i++){
			//printf("print_inodes: fileEntryTable[%d].num = %d | name %s\n", i, fileEntryTable[i].num, fileEntryTable[i].name);
			//printf("print_inodes: iNodeTable[%d].uid = %d | iNodeTable[%d].size =  %d\n", i, iNodeTable[i].uid, i, iNodeTable[i].size);
		}
}

int sfs_getnextfilename(char *fname){
	// Check if end of the line and reset it to 0
	if(numOfFiles == currFileNum){
		printf("End of the Line");
		currFileNum = 0;
		return 0;
	}
	int count = 0;
	for (int i = 0; i < FILE_ENTRY_MAX ; i++){
		if(fileEntryTable[i].num != -1){
			if(count == currFileNum){
				memcpy(fname, &fileEntryTable[i].name, sizeof(fileEntryTable[i].name));
				break;
			}
			count++;
		}
	}
	// increment for the next file
	currFileNum++;								
  	return 0;
}
//Returns the size of a given file.
int sfs_getfilesize(const char* path){

	// vaidate file name 
	if(!validate_name(path)){
		printf("Wrong File Name");
		return -1;
	}
	
	// Find the name of the file in file discriptor table
	for(int i = 0; i < 99; i++){							
		if(!strcmp(fileEntryTable[i].name, path)){
			return iNodeTable[fileEntryTable[i].num].size;
		}
	}	
	return -1;
}
/*	
	Opens a file and returns the index that corresponds
	to the newly opened file in the file descriptor table. If
	the file does not exist, it creates a new file and sets its
	size to 0. If the file does exists, the file is opened in
	append mode (i.e., set the file pointer to the end of
	the file).
*/
int sfs_fopen(char *name){
	
	// Validate File Name
	if (!validate_name (name)){
		printf("sfs_fopen: Wrong File Name\n");
		return -1;
	}
	int foundFile = 0;
	int fileInodeUID = -1;

	// Find File in File Entry table
	for(int i = 0; i < FILE_ENTRY_MAX; i++){
		if(fileEntryTable[i].num != -1){
			if(!strcmp(fileEntryTable[i].name, name)){
				foundFile = 1;
				fileInodeUID = fileEntryTable[i].num;
				break;
			}
		}
	}
	
	// File found
	if(foundFile == 1){
		// Check if file already open
		for(int i = 0; i < FD_MAX_OPEN; i++){
			if( fileDescriptorTable[i].inodeIndex ==  fileInodeUID){
				printf("sfs_fopen: File already open\n");
				return i;
			}
		}
	}
	// File not found
	else{
		
		// Find empty Inode in iNodeTable
		for(int i = 1; i <= INODE_TABLE_LEN; i ++){
			if(iNodeTable[i].size == -1){
				iNodeTable[i].size = 0;
				iNodeTable[i].data_ptrs[0] = get_index();
				inode_to_disk(i);
				fileInodeUID = iNodeTable[i].uid;
				break;
			}
		}
		// check if disk is full
		if(fileInodeUID == -1){
			//printf("sfs_fopen: Disk is full \n");
			return -1;
		}
		
		// Find empty spot in the file entry table
		int i;
		for(i = 0; i < FILE_ENTRY_MAX; i++){
			if(fileEntryTable[i].num < 0){
				strncpy(fileEntryTable[i].name, name, strlen(name));
				fileEntryTable[i].num = fileInodeUID;
				
				file_entry_to_disk();
				break;
			}
		}
		// check if disk is full
		if(i == FILE_ENTRY_MAX){
			printf("sfs_fopen:  Disk is full \n");
			return -1;
		}

		// save bitmap to disk
		bitmap_to_disk();
		// Increment total number of files
		numOfFiles++;
	}

	// Find empty stop in file descriptor table
	int fdEmpty = -1;
	int i;				
	for(i=0; i < FD_MAX_OPEN; i++){
		if(fileDescriptorTable[i].inodeIndex == -1){
			fdEmpty = i;
			break;
		}
	}
	// Check if file opening limit is full
	if(i == FD_MAX_OPEN){
		printf("sfs_fopen : File open limit exceeded\n");
		return -1;
	} 
	// Update file descriptor table
	if (foundFile == 1){
		int newWPtr = iNodeTable[fileInodeUID].size;
		fileDescriptorTable[fdEmpty] = (file_descriptor){fileInodeUID, &(iNodeTable[fileInodeUID]), newWPtr};
	}
	else{
	 	fileDescriptorTable[fdEmpty] = (file_descriptor){fileInodeUID, &(iNodeTable[fileInodeUID]), 0};	
	} 

	return fdEmpty;
	
}
/*
	Closes a file. This means you will remove the entry
	from the open file descriptor table.
*/
int sfs_fclose(int fileID) {
	if (is_file_open(fileID)== -1){
		return -1;
	}
	if(fileDescriptorTable[fileID].inodeIndex == -1){
		printf("sfs_fclose: No iNode data");
		return -1;
	}
	fileDescriptorTable[fileID] = (file_descriptor){-1,NULL,-1};

 	return 0;
}
/*
	Reads bytes of data into buf starting from the current
	file pointer.
*/
int sfs_fread(int fileID, char *buf, int length) {

	// Read the first Block
	int totalBytesRead = 0;
	// Check length
	if(length == -1){
		printf("sfs_fread: Something wrong with length");
		return -1;
	}
	// initialize buffer to used throught the function

	blockBuffer = (void*) malloc(BLOCK_SIZE);
	// Check if File is open
	int inodeIndex = is_file_open(fileID);
	if(inodeIndex == -1){
		printf("sfs_fread: File is not open.\n");
		return -1;
	}

	// check if file is empty 
	if(iNodeTable[inodeIndex].data_ptrs[0] == -1){
		printf("sfs_fread: File is empty nothing to read.\n");
		return 0;
	}

	// Return 0 if zero bytes written
	int fileSize = iNodeTable[inodeIndex].size;
	if (fileSize == 0)
	{
		printf("sfs_fread: File is empty nothing to read.\n");
		return 0;
	}
	// Get the current ptr of open file
	int curPtr = fileDescriptorTable[fileID].rwptr;
	// Get offset og the current file
	int curBlockOffset = curPtr % BLOCK_SIZE;
	// Get block number of the current file at the rwptr
	int curNumBlocks = curPtr / BLOCK_SIZE;
	// bytes to read 
	int bytesToRead = curBlockOffset + length;

	// Number of bytes to read to first block
	int firstBytesToRead;
	if (bytesToRead >  1024)
		firstBytesToRead = BLOCK_SIZE - curBlockOffset;
	else
		firstBytesToRead = bytesToRead - curBlockOffset;

	// indirect ptr
	int InDirBlock = iNodeTable[inodeIndex].indirectPointer;
	IndirPtr inDirectPointer;

	// Get the block index of the file where the rwptr location
	int ReadFromBlockStartIndex = -1;
	// Read from the direct pointer
	if (curNumBlocks < 12){

		ReadFromBlockStartIndex = iNodeTable[inodeIndex].data_ptrs[curNumBlocks];
	}
	// data stored in also indirect pointers
	else{
		memset(blockBuffer, 0, BLOCK_SIZE);
		read_blocks(InDirBlock, 1, blockBuffer);
		memcpy(&inDirectPointer, blockBuffer, sizeof(inDirectPointer));
		ReadFromBlockStartIndex = inDirectPointer.moreAddr[curNumBlocks - 12];
		
	}

	// Number of blocks to read
	int nOfBlocksToRead = (length + curBlockOffset) / BLOCK_SIZE;
	// Offset of the blocks to read
	if((length + curBlockOffset) % BLOCK_SIZE > 0)
		nOfBlocksToRead += 1;

	// size < then the read length
	if (fileSize < curPtr + firstBytesToRead)
		firstBytesToRead = (fileSize % BLOCK_SIZE) - curPtr; 


	// Write the first block
	memset(blockBuffer, 0, BLOCK_SIZE);
	read_blocks(ReadFromBlockStartIndex, 1, blockBuffer); 
	memcpy(buf, blockBuffer + curBlockOffset, firstBytesToRead);
	totalBytesRead += firstBytesToRead;

	// read the rest of the blocks except the last block
	for (int i = 1; i < nOfBlocksToRead ; i++){

		// Get the index of the next block
		int readFromIndex;
		// Reading from Direct pointer 
		//if(nOfBlocksToRead < 12)
		if (curNumBlocks + i < 12)
			readFromIndex = iNodeTable[inodeIndex].data_ptrs[curNumBlocks + i];
		// Reading from indirect pointer
		else
			readFromIndex = inDirectPointer.moreAddr[curNumBlocks + i - 12];
		int bytesToRead = BLOCK_SIZE;
		// make sure it is less than the size
		if (fileSize < i * BLOCK_SIZE + BLOCK_SIZE)
			bytesToRead = fileSize % BLOCK_SIZE;
		if( nOfBlocksToRead - 1 == i){
			bytesToRead = length - totalBytesRead;
		}

		// read the block
		memset(blockBuffer, 0, BLOCK_SIZE);
		read_blocks(readFromIndex ,1 ,blockBuffer);
		memcpy(buf + totalBytesRead,blockBuffer, bytesToRead);

		// increment the total blocks read
		totalBytesRead += bytesToRead;
	}

	// reset the read and write pointer
	free(blockBuffer);
	fileDescriptorTable[fileID].rwptr+= totalBytesRead;
   	return totalBytesRead;
}

/*
	Writes the given number of bytes of buffered data in
	buf into the open file, starting from the current file
	pointer. This in effect could increase the size of the
	file by the given number of bytes (it may not increase
	the file size by the number of bytes written if the write
	pointer is located at a location other than the end of
	the file).
*/
int sfs_fwrite(int fileID, const char *buf, int length) {

	int bytesWritten = -1;
	// Check length
	if(length == -1){
		printf("sfs_fwrite: Something wrong with length");
		return -1;
	}
	// initialize buffer to used throught the function
	blockBuffer = (void*) malloc(BLOCK_SIZE);
	
	// Check if File is open
	int inodeIndex = is_file_open(fileID);
	if(inodeIndex == -1){
		printf("sfs_fwrite: File is not open.\n");
		return bytesWritten;
	}
	// Get the current ptr of open file
	int curPtr = fileDescriptorTable[fileID].rwptr;
	// Get offset og the current file
	int curBlockOffset = curPtr % BLOCK_SIZE;
	// Get block number of the current file at the rwptr
	int curNumBlocks = curPtr / BLOCK_SIZE;

	// Bytes to write
	int bytesToWrite = curBlockOffset + length;
	// Number of bytes to write to first block
	int firstBytesToWrite;
	if (bytesToWrite >  1024)
		firstBytesToWrite = BLOCK_SIZE - curBlockOffset;
	else
		firstBytesToWrite = bytesToWrite - curBlockOffset;

	// indirect ptr
	int InDirBlock = iNodeTable[inodeIndex].indirectPointer;
	IndirPtr inDirectPointer;

	// Get the block index of the file where the rwptr location
	int writeToBlockStartIndex = -1;
	if(curNumBlocks == 0 && iNodeTable[inodeIndex].data_ptrs[0] == -1){
		writeToBlockStartIndex = get_index();
		iNodeTable[inodeIndex].data_ptrs[curNumBlocks] = writeToBlockStartIndex;
	}else if (curNumBlocks < 12){

		writeToBlockStartIndex = iNodeTable[inodeIndex].data_ptrs[curNumBlocks];
	}else{
		memset(blockBuffer, 0, BLOCK_SIZE);
		read_blocks(InDirBlock, 1, blockBuffer);
		memcpy(&inDirectPointer, blockBuffer, sizeof(inDirectPointer));
		writeToBlockStartIndex = inDirectPointer.moreAddr[curNumBlocks - 12];
	}
	
	// Number of blocks to write
	int nOfBlocksToWrite = (bytesToWrite) / BLOCK_SIZE;
	// Offset of the blocks to write 
	int toWriteBlockOffset = (bytesToWrite) % BLOCK_SIZE;
		if (toWriteBlockOffset > 0)
			nOfBlocksToWrite = nOfBlocksToWrite + 1;

	// Write the first block
	memset(blockBuffer, 0, BLOCK_SIZE);
	read_blocks(writeToBlockStartIndex, 1, blockBuffer);
	// copy everything in buffer from exiting data
	memcpy(blockBuffer + curBlockOffset, buf, firstBytesToWrite);
	write_blocks(writeToBlockStartIndex, 1, blockBuffer);

	// Write the rest of the blocks except the last block
	for (int i = 1; i < nOfBlocksToWrite ; i++){
		memset(blockBuffer, 0, BLOCK_SIZE);
		memcpy(blockBuffer, buf + ( (i-1)  * 1024) + firstBytesToWrite, BLOCK_SIZE);
		// Get index of the next block
		int writeToBlockIndex;

		// wrting indexes from direct ptr
		if (curNumBlocks + i < 12){
			if (iNodeTable[inodeIndex].data_ptrs[curNumBlocks + i] == -1){
				writeToBlockIndex = get_index();
				iNodeTable[inodeIndex].data_ptrs[curNumBlocks + i] = writeToBlockIndex;
				force_set_index(writeToBlockIndex);
				
			}else{
				writeToBlockIndex = iNodeTable[inodeIndex].data_ptrs[curNumBlocks + i];
			}
		}
		// indirect ptr
		else{
			// Check if there start time writting in in direct index
			if (iNodeTable[inodeIndex].indirectPointer == -1){
				iNodeTable[inodeIndex].indirectPointer = get_index();
				InDirBlock = iNodeTable[inodeIndex].indirectPointer;
				for(int i = 0; i <  256 ; i++){
					inDirectPointer.moreAddr[i] = -1;
				}
			}
			// Not initialized index in array
			if(inDirectPointer.moreAddr[curNumBlocks + i - 12] == -1){
				writeToBlockIndex = get_index();
				inDirectPointer.moreAddr[curNumBlocks + i - 12] = writeToBlockIndex;
			}
			// initialized
			else{
				writeToBlockIndex = inDirectPointer.moreAddr[curNumBlocks + i - 12];
			}
		}
		
		write_blocks(writeToBlockIndex, 1, blockBuffer);
	}

	// Update the file size
	curPtr = curPtr + length;
	fileDescriptorTable[fileID].rwptr = curPtr;
	if (curPtr > iNodeTable[inodeIndex].size){
		iNodeTable[inodeIndex].size = curPtr;
	}
	// update indirect ptr
	if(iNodeTable[inodeIndex].indirectPointer != -1){
		memset(blockBuffer,0, BLOCK_SIZE);
		memcpy(blockBuffer, &inDirectPointer, sizeof(inDirectPointer));
		write_blocks(InDirBlock, 1, blockBuffer);
	}
	//update in node table
	inode_to_disk(inodeIndex);
	
	// update bit map
	bitmap_to_disk();

	return length;
}
/*
	Moves the read/write pointer (a single pointer in SFS)
	to the given location.
*/
int sfs_fseek(int fileID, int loc) {
	// Check File is open
	int iNodeIndex = is_file_open(fileID);						
	if (iNodeIndex == -1){
		return -1;
	}
	if (loc < 0 || (loc >= iNodeTable[iNodeIndex].size && iNodeTable[iNodeIndex].size != 0) ){
		return -1;
	}	
  	fileDescriptorTable[fileID].rwptr = loc;
  	return 0;
}
/*
	Removes the file from the directory entry, releases the
	file allocation table entries and releases the data blocks
	used by the file, so that they can be used by new files
	in the future.
*/
int sfs_remove(char *file) {

	// Validate File name
	if(!validate_name(file)){
		printf("Wrong File Name\n");
		return -1;
	}
	char aName[28];
	strcpy(aName, file);

	int foundFile = 0;
	int iNodeindex;
	// Find the File Entry table
	for(int i = 0; i< FILE_ENTRY_MAX; i++){
		// if found clear the File entry entry and update								
		if( !strcmp(fileEntryTable[i].name, file)){
			foundFile = 1;
			iNodeindex = fileEntryTable[i].num;
			fileEntryTable[i].num = -1;
			strcmp(fileEntryTable[i].name, "");
			file_entry_to_disk();
			break;
		}
	}
	// File Not Found
	if(foundFile == 0){												
		printf("File Not Found");
		return -1;
	}
	// File Found
	else{
		// Check if file is open
		for(int i = 0; i < FD_MAX_OPEN; i++){
			// Clear up the content if found
			if(fileDescriptorTable[i].inodeIndex == iNodeindex){				
				fileDescriptorTable[i] = (file_descriptor) {-1 , NULL, -1};	
				break;
			}
		}

		// Clear up the INode Table from free bit map
		for (int i = 0; (i < 12 && iNodeTable[iNodeindex].data_ptrs[i] != -1 ) ; i++){
			rm_index(iNodeTable[iNodeindex].data_ptrs[i]);
		}														
		inode_t inode = (inode_t){777, 0, iNodeindex, 0, -1, {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1} , -1};
		iNodeTable[iNodeindex] = inode;
		if(inode_to_disk(iNodeindex)== -1){									
			printf("error in removinf node");
			return -1;
		}
	}
	// decrement global number of files
	numOfFiles--;	
  	return 0;
}

